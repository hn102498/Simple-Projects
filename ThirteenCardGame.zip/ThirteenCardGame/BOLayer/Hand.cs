﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BOLayer
{
    public class Hand
    {
        private List<Card> _cards = new List<Card>();
        public int Count
        {
            get
            {
                return _cards.Count();
            }
        }
        public Card this[int index]
        {
            get
            {
                return _cards[index];
            }
        }
        public void AddCard(Card newCard)
        {
            // the List<T>.Contains method cannot be used since it only checks if the same reference object exists
            if (ContainsCard(newCard))
            {
                throw new ConstraintException(newCard.FaceValue.ToString() + " of " +
                    newCard.Suit.ToString() + " already exists in the Handsss");
            }
            _cards.Add(newCard);
            // Little test to show them the fact that the Contains method cannot be used
            //Card a = new Card(Suit.Clubs, FaceValue.Ace);
            //_cards.Add(a);
            //Card b = new Card(Suit.Clubs, FaceValue.Ace);
            //if (_cards.Contains(b))
            //{
            //    throw new ConstraintException(newCard.FaceValue.ToString() + " of " +
            //        newCard.Suit.ToString() + " already exists in the Hand");
            //}
        }
        private bool ContainsCard(Card cardToCheck)
        {
            foreach (Card card in _cards)
            {
                if (card.FaceValue == cardToCheck.FaceValue && card.Suit == cardToCheck.Suit)
                {
                    return true;
                }
            }
            // OR
            //for(int i = 0; i < _cards.Count; i++)
            //{
            //    if(_cards[i].FaceValue == cardToCheck.FaceValue && _cards[i].Suit == cardToCheck.Suit)
            //    {
            //        return true;
            //    }
            //}
            return false;
        }

        public void RemoveCard(Card theCard)
        {
            if (!ContainsCard(theCard))
            {
                
                throw new ArgumentException("The hand doesn't hold that card"+theCard.FaceValue.ToString()+"of"+theCard.Suit);
            }
            _cards.Remove(theCard);
        }

        public void RemoveCard(int index)
        {
            if(index > _cards.Count - 1)
            {
                throw new ArgumentException("Exceed number of index of the cards");
            }
            _cards.RemoveAt(index);
        }

        public void Clear()
        {
            _cards.Clear();
        }
    }
}