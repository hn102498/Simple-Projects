﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOLayer
{
    public static class Validation
    {
        public static bool ValidSingle(Hand chosenCards,Hand onTable)
        {
            if (onTable.Count == 1 && chosenCards.Count == 1)
            {
                if (chosenCards.Count == 1 && ((chosenCards[0].FaceValue > onTable[0].FaceValue) || (onTable[0].FaceValue == chosenCards[0].FaceValue && onTable[0].Suit < chosenCards[0].Suit)))
                {
                    return true;
                }
                else if (onTable[0].FaceValue == FaceValue.Two && chosenCards.Count == 4)
                {
                    FaceValue compareFace = chosenCards[0].FaceValue;
                    bool isValid = false;
                    for (int i = 0; i < chosenCards.Count; i++)
                    {
                        if (chosenCards[i].FaceValue == compareFace)
                        {
                            isValid = true;
                        }
                        else
                        {
                            isValid = false;
                            break;
                        }
                    }
                    return isValid;
                }
                else { return false; }
            }
            else { return false; }

        }

        public static bool ValidDouble(Hand chosenCards,Hand onTable)
        {
            if (onTable.Count == 0 && chosenCards.Count == 2)
            {
                if (chosenCards[0].FaceValue == chosenCards[1].FaceValue)
                { return true; }
                else { return false; }
            }
            else if (onTable.Count == 2 && chosenCards.Count == 2)
            {
                if (chosenCards[0].FaceValue == chosenCards[1].FaceValue)
                {
                    if (chosenCards[0].FaceValue > onTable[0].FaceValue)
                    {
                        return true;
                    }
                    else if (onTable[0].FaceValue == chosenCards[0].FaceValue)
                    {
                        if ((chosenCards[0].Suit > onTable[0].Suit && chosenCards[0].Suit > onTable[1].Suit) || (chosenCards[1].Suit > onTable[0].Suit && chosenCards[1].Suit > onTable[1].Suit))
                        {
                            return true;
                        }
                        else { return false; }
                    }
                    else { return false; }
                }

                else if (onTable[0].FaceValue == FaceValue.Two && chosenCards.Count == 4)
                {
                    FaceValue compareFace;
                    compareFace = chosenCards[0].FaceValue;
                    bool isValid = false;
                    for (int i = 0; i < chosenCards.Count; i++)
                    {
                        if (chosenCards[i].FaceValue == compareFace)
                        {
                            isValid = true;
                        }
                        else
                        {
                            isValid = false;
                            break;
                        }
                    }
                    return isValid;
                }
                else { return false; }
            }
            else { return false; }
        }

        public static bool ValidStreak(Hand chosenCards, Hand onTable)
        {
            if (onTable.Count == 0 || (onTable.Count >= 3 && onTable[0].FaceValue != onTable[1].FaceValue))
            {
                for (int i = 0; i < chosenCards.Count - 1; i++)
                {
                    if (chosenCards[i + 1].FaceValue - chosenCards[i].FaceValue != 1)
                    {
                        return false;
                    }
                }
                for (int j = 0; j < chosenCards.Count; j++)
                {
                    if ((int)chosenCards[j].FaceValue > 11)
                    {
                        return false;
                    }
                }
                if (chosenCards.Count == onTable.Count && chosenCards[0].FaceValue > onTable[0].FaceValue)
                {
                    return true;
                    //Hand newCards = LineUp(chosenCards);
                    //chosenCards = newCards;

                }
                else if (chosenCards.Count == onTable.Count && chosenCards[0].FaceValue == onTable[0].FaceValue)
                {
                    if (chosenCards[chosenCards.Count - 1].Suit > onTable[onTable.Count - 1].Suit)
                    {
                        return true;
                    }
                    else { return false; }
                }
                else { return false; }
            }
            else { return false; }
        }
    }
}
