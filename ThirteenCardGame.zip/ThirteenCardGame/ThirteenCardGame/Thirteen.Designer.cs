﻿namespace ThirteenCardGame
{
    partial class Thirteen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Thirteen));
            this.btnNew = new System.Windows.Forms.Button();
            this.pnlTable = new System.Windows.Forms.Panel();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnSkip = new System.Windows.Forms.Button();
            this.pnlPlayer = new System.Windows.Forms.Panel();
            this.pnlComp = new System.Windows.Forms.Panel();
            this.tComp = new System.Windows.Forms.Timer(this.components);
            this.pnlDone = new System.Windows.Forms.Panel();
            this.btnLineUp = new System.Windows.Forms.Button();
            this.lblTimer = new System.Windows.Forms.Label();
            this.tPlayer = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // btnNew
            // 
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.Location = new System.Drawing.Point(662, 203);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(95, 87);
            this.btnNew.TabIndex = 4;
            this.btnNew.Text = "New Round";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // pnlTable
            // 
            this.pnlTable.BackColor = System.Drawing.Color.Transparent;
            this.pnlTable.Location = new System.Drawing.Point(213, 177);
            this.pnlTable.Name = "pnlTable";
            this.pnlTable.Size = new System.Drawing.Size(443, 146);
            this.pnlTable.TabIndex = 9;
            // 
            // btnPlay
            // 
            this.btnPlay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlay.Location = new System.Drawing.Point(682, 432);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 47);
            this.btnPlay.TabIndex = 7;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnSkip
            // 
            this.btnSkip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSkip.Location = new System.Drawing.Point(682, 386);
            this.btnSkip.Name = "btnSkip";
            this.btnSkip.Size = new System.Drawing.Size(75, 40);
            this.btnSkip.TabIndex = 8;
            this.btnSkip.Text = "Skip Turn";
            this.btnSkip.UseVisualStyleBackColor = true;
            this.btnSkip.Click += new System.EventHandler(this.btnSkip_Click);
            // 
            // pnlPlayer
            // 
            this.pnlPlayer.BackColor = System.Drawing.Color.Transparent;
            this.pnlPlayer.Location = new System.Drawing.Point(122, 329);
            this.pnlPlayer.Name = "pnlPlayer";
            this.pnlPlayer.Size = new System.Drawing.Size(529, 150);
            this.pnlPlayer.TabIndex = 5;
            // 
            // pnlComp
            // 
            this.pnlComp.BackColor = System.Drawing.Color.Transparent;
            this.pnlComp.Location = new System.Drawing.Point(122, 11);
            this.pnlComp.Name = "pnlComp";
            this.pnlComp.Size = new System.Drawing.Size(529, 150);
            this.pnlComp.TabIndex = 6;
            // 
            // tComp
            // 
            this.tComp.Interval = 1500;
            this.tComp.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pnlDone
            // 
            this.pnlDone.BackColor = System.Drawing.Color.Transparent;
            this.pnlDone.Location = new System.Drawing.Point(12, 180);
            this.pnlDone.Name = "pnlDone";
            this.pnlDone.Size = new System.Drawing.Size(167, 146);
            this.pnlDone.TabIndex = 9;
            // 
            // btnLineUp
            // 
            this.btnLineUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLineUp.Location = new System.Drawing.Point(682, 329);
            this.btnLineUp.Name = "btnLineUp";
            this.btnLineUp.Size = new System.Drawing.Size(75, 23);
            this.btnLineUp.TabIndex = 11;
            this.btnLineUp.Text = "Line Up";
            this.btnLineUp.UseVisualStyleBackColor = true;
            this.btnLineUp.Click += new System.EventHandler(this.btnLineUp_Click);
            // 
            // lblTimer
            // 
            this.lblTimer.BackColor = System.Drawing.Color.Transparent;
            this.lblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.ForeColor = System.Drawing.Color.Red;
            this.lblTimer.Location = new System.Drawing.Point(679, 24);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(109, 125);
            this.lblTimer.TabIndex = 0;
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tPlayer
            // 
            this.tPlayer.Interval = 1000;
            // 
            // Thirteen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 499);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.btnLineUp);
            this.Controls.Add(this.pnlDone);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.pnlTable);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnSkip);
            this.Controls.Add(this.pnlPlayer);
            this.Controls.Add(this.pnlComp);
            this.Name = "Thirteen";
            this.Text = "Thirteen";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Panel pnlTable;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnSkip;
        private System.Windows.Forms.Panel pnlPlayer;
        private System.Windows.Forms.Panel pnlComp;
        private System.Windows.Forms.Timer tComp;
        private System.Windows.Forms.Panel pnlDone;
        private System.Windows.Forms.Button btnLineUp;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Timer tPlayer;
    }
}