﻿using BOLayer;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ThirteenCardGame
{


    public partial class Thirteen : Form
    {
        public Thirteen()
        {
            InitializeComponent();
        }

        Deck aDeck = new Deck();
        Hand compHand;
        Hand playerHand;
        Hand onTable;
        Hand chosenCards;
        List<Card> theCards = new List<Card>();
        bool playerTurn = true;

        private void SetUp()
        {
            try
            {
                aDeck = new Deck();
                aDeck.Shuffle();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void ShowHand(Hand theHand, Panel thePanel)
        {
            thePanel.Controls.Clear();
            Card aCard;
            PictureBox aPic;

            for (int i = 0; i < theHand.Count; i++)
            {

                aCard = theHand[i];

                string imgPath = "images\\" + aCard.FaceValue + aCard.Suit + ".jpg";

                aPic = new PictureBox()
                {
                    Image = Image.FromFile(imgPath),
                    Width = 70,
                    Height = 96,
                    Left = 75 * i / 2,
                    Top = 50,
                    Tag = aCard
                };

                aPic.Click += APic_Click;
                thePanel.Controls.Add(aPic);
                aPic.BringToFront();
            }

        }

        private void ShowCompHand(Hand theHand, Panel thePanel)
        {
            thePanel.Controls.Clear();
            Card aCard;
            PictureBox aPic;

            for (int i = 0; i < theHand.Count; i++)
            {

                aCard = theHand[i];

                string imgPath = "images\\cardback.gif";

                aPic = new PictureBox()
                {
                    Image = Image.FromFile(imgPath),
                    Width = 70,
                    Height = 96,
                    Left = 75 * i / 2,
                    Top = 50,
                    Tag = aCard
                };

                aPic.Click += APic_Click;
                thePanel.Controls.Add(aPic);
                aPic.BringToFront();
            }
        }


        private void APic_Click(object sender, EventArgs e)
        {
            lblTimer.ResetText();
            PictureBox pic = (PictureBox)sender;
            if (pnlPlayer.Contains(pic))
            {
                if (pic.Top == 50)
                {
                    pic.Top -= 20;
                    chosenCards.AddCard((Card)pic.Tag);
                    theCards.Add((Card)pic.Tag);
                }
                else if (pic.Top == 30)
                {
                    pic.Top += 20;
                    chosenCards.RemoveCard((Card)pic.Tag);
                    theCards.Remove((Card)pic.Tag);
                }
            }

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            if (aDeck.Count() == 52 || playerHand.Count == 0 || compHand.Count == 0)
            {
                SetUp();
                compHand = aDeck.DealHand(13);
                playerHand = aDeck.DealHand(13);
                onTable = new Hand();
                chosenCards = new Hand();
                ShowCompHand(compHand, pnlComp);
                ShowHand(playerHand, pnlPlayer);
                ShowHand(onTable, pnlTable);
                pnlDone.Controls.Clear();
            }
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            Hand newCards = LineUp(chosenCards);
            chosenCards = newCards;
            if (playerTurn == false)
            {
                MessageBox.Show("It's AI turn");
            }
            else if (chosenCards.Count == 0)
            {
                MessageBox.Show("Choose at least one card to play");
            }

            if (ValidPlay(chosenCards))
            {
                if (pnlTable.Controls.Count == 0)
                {

                    foreach (Card card in theCards)
                    {
                        onTable.AddCard(card);
                    }
                    foreach (Card card in theCards)
                    {
                        playerHand.RemoveCard(card);
                        chosenCards.RemoveCard(card);
                    }
                    theCards.Clear();
                    ShowHand(onTable, pnlTable);
                    ShowHand(playerHand, pnlPlayer);

                }
                else if (pnlTable.Controls.Count != 0)
                {

                    onTable.Clear();
                    foreach (Card card in theCards)
                    {
                        onTable.AddCard(card);
                    }
                    foreach (Card card in theCards)
                    {
                        playerHand.RemoveCard(card);
                        chosenCards.RemoveCard(card);
                    }

                    for (int i = 0; i < onTable.Count; i++)
                    {
                        PictureBox aPic;

                        string imgPath = "images\\cardback.gif";

                        aPic = new PictureBox()
                        {
                            Image = Image.FromFile(imgPath),
                            Width = 70,
                            Height = 96,
                            Left = 2 + i * 2,
                            Top = 50,
                        };
                        pnlDone.Controls.Add(aPic);
                        aPic.BringToFront();
                    }

                    theCards.Clear();
                    ShowHand(onTable, pnlTable);
                    ShowHand(playerHand, pnlPlayer);

                }

                if (playerHand.Count == 0)
                {

                    compHand.Clear();
                    onTable.Clear();
                    ShowCompHand(compHand, pnlComp);
                    ShowHand(onTable, pnlTable);
                    tComp.Stop();
                    MessageBox.Show("You win!!");
                }
                else if (compHand.Count == 0)
                {

                    playerHand.Clear();
                    onTable.Clear();
                    ShowHand(playerHand, pnlPlayer);
                    ShowHand(onTable, pnlTable);
                    tComp.Stop();
                    MessageBox.Show("You must be 2 or less to lose this :)", "Congratulations!");
                }
                else
                {
                    playerTurn = false;
                    tComp.Start();
                }
            }
        }

        private bool ValidPlay(Hand chosenCards)
        {
            if (onTable.Count == 0)
            {
                return true;
            }
            else if (onTable.Count == 1 && Validation.ValidSingle(chosenCards, onTable))
            {
                return true;
            }
            else if (onTable.Count == 2 && Validation.ValidDouble(chosenCards, onTable))
            {
                return true;
            }
            else if (onTable.Count >= 3 && Validation.ValidStreak(chosenCards, onTable))
            {
                return true;
            }
            else { return false; }
        }









        private Hand LineUp(Hand chosenCards)
        {
            Hand lineUp = new Hand();

            while (chosenCards.Count != 0)
            {
                Card minCard = chosenCards[0];
                for (int i = 0; i < chosenCards.Count; i++)
                {
                    if (minCard.FaceValue > chosenCards[i].FaceValue)
                    {
                        minCard = chosenCards[i];
                    }
                }
                lineUp.AddCard(minCard);
                chosenCards.RemoveCard(minCard);
            }



            return lineUp;
        }

        private void btnLineUp_Click(object sender, EventArgs e)
        {
            chosenCards.Clear();
            theCards.Clear();
            playerHand = LineUp(playerHand);
            compHand = LineUp(compHand);
            ShowHand(playerHand, pnlPlayer);
            ShowCompHand(compHand, pnlComp);
        }

        private void btnSkip_Click(object sender, EventArgs e)
        {
            if (onTable.Count == 0)
            {
                MessageBox.Show("You cannot skipp a free play");
            }
            else
            {
                for (int i = 0; i < onTable.Count; i++)
                {
                    PictureBox aPic;

                    string imgPath = "images\\cardback.gif";

                    aPic = new PictureBox()
                    {
                        Image = Image.FromFile(imgPath),
                        Width = 70,
                        Height = 96,
                        Left = 2 + i * 2,
                        Top = 50,
                    };
                    pnlDone.Controls.Add(aPic);
                    aPic.BringToFront();
                }
                onTable.Clear();
                ShowHand(onTable, pnlTable);
                if (playerTurn == true)
                {
                    playerTurn = false;

                }
                else if (playerTurn == false)
                {
                    playerTurn = true;
                    timer1_Tick(null, null);
                    tComp.Stop();

                }
            }
        }

        private void CompTurn()
        {
            if (playerTurn == false)
            {
                List<Card> theCards = new List<Card>();
                if (onTable.Count == 0 && compHand.Count != 0 && playerHand.Count != 0)
                {
                    Random ran = new Random();
                    theCards.Add(compHand[ran.Next(compHand.Count)]);
                }
                else if (onTable.Count == 1)
                {
                    for (int i = 0; i < compHand.Count; i++)
                    {
                        if (compHand[i].FaceValue > onTable[0].FaceValue)
                        {
                            theCards.Add(compHand[i]);
                            onTable.RemoveCard(onTable[0]);
                            break;
                        }
                    }
                }

                else if (onTable.Count == 2)
                {

                    for (int i = 0; i < compHand.Count - 1; i++)
                    {
                        if (compHand[i].FaceValue == compHand[i + 1].FaceValue)
                        {
                            if (compHand[i].FaceValue > onTable[0].FaceValue)
                            {
                                theCards.Add(compHand[i]);
                                theCards.Add(compHand[i + 1]);
                                onTable.Clear();
                                break;
                            }
                            break;
                        }
                    }

                }
                if (theCards.Count == 0 && compHand.Count != 0)
                {
                    btnSkip_Click(null, null);
                    lblTimer.Text = "Computer skipped turn";

                }
                else
                {
                    foreach (Card card in theCards)
                    {
                        onTable.AddCard(card);
                        compHand.RemoveCard(card);
                    }
                    for (int i = 0; i < onTable.Count; i++)
                    {
                        PictureBox aPic;

                        string imgPath = "images\\cardback.gif";

                        aPic = new PictureBox()
                        {
                            Image = Image.FromFile(imgPath),
                            Width = 70,
                            Height = 96,
                            Left = 2 + i * 2,
                            Top = 50,
                        };
                        pnlDone.Controls.Add(aPic);
                        aPic.BringToFront();
                    }
                    ShowHand(onTable, pnlTable);
                    ShowCompHand(compHand, pnlComp);
                }
                if (playerHand.Count == 0)
                {

                    compHand.Clear();
                    onTable.Clear();
                    ShowCompHand(compHand, pnlComp);
                    ShowHand(onTable, pnlTable);
                    tComp.Stop();
                    MessageBox.Show("You win!!");
                }
                else if (compHand.Count == 0)
                {

                    playerHand.Clear();
                    onTable.Clear();
                    ShowHand(playerHand, pnlPlayer);
                    ShowHand(onTable, pnlTable);
                    tComp.Stop();
                    MessageBox.Show("You must be 2 or less to lose this :)", "Congratulations!");
                }
                else
                {
                    playerTurn = true;
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            CompTurn();
        }


    }
}